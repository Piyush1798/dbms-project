-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 14, 2020 at 12:30 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bike rental`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `user_id` varchar(10) NOT NULL,
  `password` varchar(20) NOT NULL,
  `admin name` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user_id`, `password`, `admin name`) VALUES
('pandya420', '123', 'mmk');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `booking_id` varchar(10) NOT NULL,
  `veh_id` varchar(20) DEFAULT NULL,
  `user_id` varchar(20) DEFAULT NULL,
  `in_date` varchar(15) DEFAULT NULL,
  `out_date` varchar(15) DEFAULT NULL,
  `in_time` varchar(15) DEFAULT NULL,
  `out_time` varchar(15) DEFAULT NULL,
  `decision` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`booking_id`, `veh_id`, `user_id`, `in_date`, `out_date`, `in_time`, `out_time`, `decision`) VALUES
('60', '456', '12345', '07 14 2020', '14 07 2020', '1 23 3', '3 4 4', 'pending'),
('82', '76', 'alaric', '06 1 2020', '10 06 2020', '7 u 1', '7 8 9', 'pending'),
('84', '789', 'alaric', '06 17 2020', '17 06 2020', '1 00 00', '2 00 00', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` varchar(20) NOT NULL,
  `password` varchar(10) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `phone` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `password`, `user_name`, `phone`) VALUES
('1234', 'qwer', 'MANGLESH PANDYA', '991920'),
('12345', 'lnd', 'chut', '998128319'),
('2345', 'qwer', 'MANGLESH PANDYA', '998128319'),
('789', '123', '. llkmk', 'l;l;'),
('alaric', '12345', 'rahul', '9981283198'),
('chutiya', '', 'lwjne', '980980'),
('elwn', 'password', 'user_name', 'phone'),
('khkuhk', '', 'kyi', '9767'),
('mangoo', '', 'lwjne', '980980');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `veh_id` varchar(15) NOT NULL,
  `veh_type` varchar(10) NOT NULL,
  `brand_name` varchar(20) NOT NULL,
  `price` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`veh_id`, `veh_type`, `brand_name`, `price`) VALUES
('1235', 'bike', 'ayabhusa', '10'),
('12365', 'scooty', 'ayuabhusa', '500'),
('456', 'bike', 'ayabhusa', '100'),
('76', 'bike', 'ayabhusa', '10'),
('788', 'bike', 'ayuabhusa', '500'),
('789', 'scooty', 'jhv', '22'),
('78965', 'bike', 'suzuki', '120'),
('dd', 'bike', 'sds', 'e23');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`booking_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `veh_id` (`veh_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`veh_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `book`
--
ALTER TABLE `book`
  ADD CONSTRAINT `book_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `book_ibfk_2` FOREIGN KEY (`veh_id`) REFERENCES `vehicle` (`veh_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
