<?php
session_start();
if(!isset($_SESSION["user"]))
{
    ?>
    <script>
       
        window.history.back();
        </script>
    <?php
    

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="stylesheet" href="loginstyle.css">
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    /* Set height of the grid so .sidenav can be 100% (adjust if needed) */
    .row.content {height: 1500px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      background-color: #f1f1f1;
      height: 100%;
    }
    
    /* Set black background color, white text and some padding */
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
    
    /* On small screens, set height to 'auto' for sidenav and grid */
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height: auto;} 
    }
   .ddd 
   {
    height: 600px;
    width : 400px;
    margin-left: 50%;
    margin-right: 50%;
    margin-top: 10%;
    box-sizing:border-box;
    border-radius: 3px;
    border: 1px solid white;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.9);
   }
   .ddd ul 
   {
     list-style-type: none;
   }
   label 
   {
     color:black;
   }
  </style>
</head>
<body>

<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav">
     
      <h4>Admin's dashboard</h4>
      <ul class="nav nav-pills nav-stacked">
        <li class="active"><a href="#section1">Home</a></li>
        <li><a href="admin add vehicle.php">add vehicle</a></li>
        <li><a href="admin manage booking.php">manage booking</a></li>
        <li><a href="admin find vehicle.php">find vehicle</a></li>
        <li><a href="admin change password.php">change password</a></li>
        <li><a href="admin logout.php">logout</a></li>
      </ul><br>
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search Blog..">
        <span class="input-group-btn">
          <button class="btn btn-default" type="button">
            <span class="glyphicon glyphicon-search"></span>
          </button>
        </span>
      </div>
    </div>
    <div class="ddd">
    <form id="form_112471"  class="form-horizontalclass" class="appnitro" class="form-group"  method="post" action="admin adding.php">
					<div class="form_description">
			<h2 style="text-align:center;">Add vehicle </h2>
			
		</div>
    <ul >
			
					<li id="li_1" >
		<label class="description" for="element_1">vehicle id </label>
		<div>
			<input id="element_1" name="vehicle_id" name="element_1" class="element text medium" type="text" maxlength="255" value=""/> 
		</div> 
		</li>		<li id="li_4" >
		<label class="description" for="element_4">vehicle type </label>
		<span>
			<input style="margin-left:5%;" id="element_4_1" name="radio" name="element_4" class="element radio" type="radio" value="bike" />
<label class="choice" for="element_4_1">bike</label>
<input style="margin-left:5%;" name="radio" id="element_4_2" name="element_4" class="element radio" type="radio" value="scooty" />
<label class="choice" for="element_4_2">scooty</label>

		</span> 
		</li>		<li id="li_2" >
		<label class="description" for="element_2">brand name </label>
		<div>
			<input name="bname"  id="element_2" name="element_2" class="element text medium" type="text" maxlength="255" value=""/> 
		</div> 
		</li>		<li id="li_3" >
		<label class="description" for="element_3">price </label>
		<div>
			<input name="price" id="element_3" name="element_3" class="element text medium" type="text" maxlength="255" value=""/> 
		</div> 
		</li>
			
					<li class="buttons">
			    <input type="hidden" name="form_id" value="112471" />
			    
				<input id="saveForm" class="button_text" type="submit" name="submit" value="Submit" />
		</li>
            </ul>
       </form>
    </div>
    
</div>
</div>

<footer class="container-fluid">
  <p>Footer Text</p>
</footer>
</body>
</html>
  