<?php
session_start();
if(!isset($_SESSION["user"]))
{
    ?>
    <script>
       
        window.history.back();
        </script>
    <?php
    

}
$servername = "localhost";
$username="root";
$password="";
$dbname="bike rental";
//stablish connection 
$conn= new mysqli($servername,$username,$password,$dbname);
//check connection
if($conn->connect_error)
{
  die("could not connect:");
}
$user_i= $_POST["vehicle_id"]; 
$pass= $_POST["radio"];
$name=$_POST["bname"]; 
$mob_no=$_POST["price"]; 

$sql="INSERT INTO vehicle (veh_id,veh_type, brand_name,price)
VALUES ('$user_i','$pass','$name','$mob_no')";
if($conn->query($sql)==true)
{
  
  ?>
  <script>
  alert("data inserted");
  window.history.back();
  </script>
  <?php
}
else
{
    ?>
    <script>
    alert("please write the unique id");
    window.history.back();
    </script>
    <?php
}
?>