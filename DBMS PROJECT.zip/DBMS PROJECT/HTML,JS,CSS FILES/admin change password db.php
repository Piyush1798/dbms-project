<?php
session_start();
if(!isset($_SESSION["user"]))
{
    ?>
    <script>
        
        window.history.back();
        </script>
    <?php
    

}
else{
$servername = "localhost";
$username="root";
$password="";
$dbname="bike rental";
//stablish connection 
$conn= new mysqli($servername,$username,$password,$dbname);
//check connection
if($conn->connect_error)
{
  die("could not connect:");
}
$old_pass= $_POST["vehicle_id"]; 

$new_pass=$_POST["bname"]; 
$confirm_pass=$_POST["price"]; 
?>
<script>


</script>
<?php
if(!($confirm_pass==$new_pass))
{
    echo"hello";
    ?>
    <script>
        alert("plese write the same password in confirm password");
        window.history.back();
        </script>
    <?php
}
else{
$u_id=$_SESSION["user"];
$sql="SELECT * FROM admin WHERE user_id='$u_id' and password='$old_pass'";
$result=$conn->query($sql);

if($result->num_rows>0)
{
    $sql2="UPDATE admin SET password ='$new_pass' WHERE user_id = '$u_id'";
    if($conn->query($sql2)==true)
    {
        session_destroy();
  	unset($_SESSION['user']);
        ?>
         <script>
        
        window.history.back();
        </script>
        <?php
        
    }   
    else
    {
        ?>
        <script>
            alert("something went wrong");
        </script>
        <?php
    }
}
else
{
  ?>
  <script>
      alert("old password is wrong");
      window.history.back();
    </script>
  <?php
  
}
}
}
?>