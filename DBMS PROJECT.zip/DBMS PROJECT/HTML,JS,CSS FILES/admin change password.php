<?php
session_start();
if(!isset($_SESSION["user"]))
{
    ?>
    <script>
        
        window.history.back();
        </script>
    <?php
    

}
?>
<!DOCTYPE html>
<html lang="en">
<head>

  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    /* Set height of the grid so .sidenav can be 100% (adjust if needed) */
    .row.content {height: 1500px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      background-color: #f1f1f1;
      height: 100%;
    }
    
    /* Set black background color, white text and some padding */
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
    
    /* On small screens, set height to 'auto' for sidenav and grid */
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height: auto;} 
    }
   .ddd 
   {
    height: 600px;
    width : 400px;
    margin-left: 50%;
    margin-right: 50%;

   }
   .head h1
  {
    font-family: "Arial Black", Gadget, sans-serif;
font-size: 29px;
letter-spacing: -0.2px;
word-spacing: 1px;
color: #000000;
font-weight: 700;
text-decoration: none;
font-style: normal;
font-variant: normal;
text-transform: uppercase;
text-align: center;
  }
  </style>
</head>
<body>

<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav">
     
      <h4>Admin's dashboard</h4>
      <ul class="nav nav-pills nav-stacked">
        <li ><a href="#section1">Home</a></li>
        <li><a href="admin add vehicle.php">add vehicle</a></li>
        <li ><a href="admin manage booking.php">manage booking</a></li>
        <li ><a href="admin find vehicle.php">find vehicle</a></li>
        <li class="active" ><a href="admin change password.php">change password</a></li>
        <li><a href="admin logout.php">logout</a></li>
      </ul><br>
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search Blog..">
        <span class="input-group-btn">
          <button class="btn btn-default" type="button">
            <span class="glyphicon glyphicon-search"></span>
          </button>
        </span>
      </div>
    </div>
    <div class="head">
    <h1>change password<h1>
    </div>
    <div class="ddd">
    <form id="form_112471"  class="form-horizontalclass" class="appnitro" class="form-group"  method="post" action="admin change password db.php">
					<div class="form_description">
			
			
		</div>
    <ul >
			
					<li id="li_1" >
		<label class="description" for="element_1">old password</label>
		<div>
			<input required id="element_1" name="vehicle_id" name="element_1" class="element text medium" type="text" maxlength="255" value=""/> 
		</div> 
    </li>		
    	<li id="li_2" >
		<label class="description" for="element_2">new password</label>
		<div>
			<input required name="bname"  id="element_2" name="element_2" class="element text medium" type="text" maxlength="255" value=""/> 
		</div> 
		</li>		<li id="li_3" >
		<label class="description" for="element_3">confirm password </label>
		<div>
			<input required  name="price" id="element_3" name="element_3" class="element text medium" type="text" maxlength="255" value=""/> 
		</div> 
		</li>
			
					<li class="buttons">
			    <input type="hidden" name="form_id" value="112471" />
			    
				<input id="saveForm" class="button_text" type="submit" name="submit" value="Submit" />
		</li>
            </ul>
       </form>
    </div>

</div>
</div>

<footer class="container-fluid">
  <p>Footer Text</p>
</footer>

</body>
</html>
