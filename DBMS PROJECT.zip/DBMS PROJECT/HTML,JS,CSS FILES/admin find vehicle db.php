<?php
session_start();
if(!isset($_SESSION["user"]))
{
    ?>
    <script>
       
        window.history.back();
        </script>
    <?php
    

}
else
{
    $servername="localhost";
    $password="";
    $username="root";
    $dbname="bike rental";
    //con making;
    $conn=new mysqli($servername,$username,$password,$dbname);
    if($conn->connect_error)
    {
        die("cannot connect");
    }
    
    $veh_id=$_POST["s"];
    $sql="SELECT * FROM vehicle WHERE veh_id='$veh_id'";
    $result=$conn->query($sql);
    if($result->num_rows>0)
    {
        while($row=$result->fetch_assoc())
        {
           $vv=$row['veh_id'];
            ?>
           <script type="text/javascript">
    var id = "<?php echo $vv; ?>";
    var vtype="<?php echo $row['veh_type']; ?>";
    var bname="<?php echo $row['brand_name']; ?>";
    var price="<?php echo $row['price']; ?>";
    
</script>
           <?php
        }
    }
    else{
        echo "some error";
    }

}
?>