<?php
session_start();
if(!isset($_SESSION["user"]))
{
    ?>
    <script>
       
        window.history.back();
        </script>
    <?php
    

}
?>
<!DOCTYPE html>
<html lang="en">
<head>

  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
  <style>
    /* Set height of the grid so .sidenav can be 100% (adjust if needed) */
    .row.content {height: 1500px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      background-color: #f1f1f1;
      height: 100%;
    }
    
    /* Set black background color, white text and some padding */
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
    
    /* On small screens, set height to 'auto' for sidenav and grid */
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height: auto;} 
    }
   .ddd 
   {
    height: 600px;
    width : 400px;
    margin-left: 50%;
    margin-right: 50%;

   }
  h1
  {
    font-family: "Arial Black", Gadget, sans-serif;
font-size: 29px;
letter-spacing: -0.2px;
word-spacing: 1px;
color: #000000;
font-weight: 700;
text-decoration: none;
font-style: normal;
font-variant: normal;
text-transform: uppercase;
text-align: center;

  }
  .show 
  {
    text-align: center;
    margin-left:40%;
  }
  .decorate
{
    

letter-spacing: 2px;
word-spacing: 2px;
color: #000000;
font-weight: 700;
text-decoration: none;
font-style: normal;
font-variant: normal;
text-transform: none;

margin-top:10px;

padding:10px;
padding-left:10px;
padding-right:10px;
}
table {
  border-collapse: collapse;
  text-align:center;
}

th, td {
  text-align: left;
  padding: 8px;
}

th {background-color: #f2f2f2;}
  </style>
</head>
<body>

<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav">
     
      <h4>Admin's dashboard</h4>
      <ul class="nav nav-pills nav-stacked">
        <li ><a href="#section1">Home</a></li>
        <li><a href="admin add vehicle.php">add vehicle</a></li>
        <li ><a href="admin manage booking.php">manage booking</a></li>
        <li  class="active" ><a href="admin find vehicle.php">find vehicle</a></li>
        <li><a href="admin change password.php">change password</a></li>
        <li><a href="admin logout.php">logout</a></li>
      </ul><br>
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search Blog..">
        <span class="input-group-btn">
          <button class="btn btn-default" type="button">
            <span class="glyphicon glyphicon-search"></span>
          </button>
        </span>
      </div>
    </div>
    <h1> find vehicle</h1>
    <form method="post" action="admin find vehicle.php">
  <div class="input-group ">
  
    <input required name="s" type="text" class="form-control" placeholder="Search" value="">
   
    <div class="input-group-btn">
      <button class="btn btn-default" type="submit">
        <i class="glyphicon glyphicon-search"></i>
      </button>
      
    </div>
    
  </div>
</form>

<table  class="show" style="overflow-x:auto; " >
<tr>
   
</tr>
<tr>
    
</tr>
</table>

</div>
</div>

<footer class="container-fluid">
  <p>Footer Text</p>
</footer>

</body>
</html>



<?php
session_start();
if(!isset($_SESSION["user"]))
{
    ?>
    <script>
       
        window.history.back();
        </script>
    <?php
    

}
else
{
    $servername="localhost";
    $password="";
    $username="root";
    $dbname="bike rental";
    //con making;
    $conn=new mysqli($servername,$username,$password,$dbname);
    if($conn->connect_error)
    {
        die("cannot connect");
    }
    
    $veh_id=$_POST["s"];
    $sql="SELECT * FROM vehicle WHERE veh_id='$veh_id'";
    $result=$conn->query($sql);
    if($result->num_rows>0)
    {
        while($row=$result->fetch_assoc())
        {
           $vv=$row['veh_id'];
            ?>
           <script type="text/javascript">
    var id = "<?php echo $vv; ?>";
    var vtype="<?php echo $row['veh_type']; ?>";
    var bname="<?php echo $row['brand_name']; ?>";
    var price="<?php echo $row['price']; ?>";
    var btn = document.createElement("th");
    btn.innerHTML="vehicle id";
    btn.classList.add("decorate");
    document.querySelector('.show tr').appendChild(btn);
    var btn1 = document.createElement("th");
    btn1.innerHTML="vehicle type";
    btn1.classList.add("decorate");
    document.querySelector('.show tr').appendChild(btn1);
    var btn2 = document.createElement("th");
    btn2.innerHTML="vehicle brand";
    btn2.classList.add("decorate");
    document.querySelector('.show tr').appendChild(btn2);
    var btn3 = document.createElement("th");
    btn3.innerHTML="vehicle price";
    btn3.classList.add("decorate");
    document.querySelector('.show tr').appendChild(btn3);
    var td1 = document.createElement("td");
    td1.innerHTML=id;
    td1.classList.add("decorate");
    document.querySelectorAll('.show tr')[1].appendChild(td1);
    var td2 = document.createElement("td");
    td2.innerHTML=vtype;
    td2.classList.add("decorate");
    document.querySelectorAll('.show tr')[1].appendChild(td2);
    var td3 = document.createElement("td");
    td3.innerHTML=bname;
    td3.classList.add("decorate");
    document.querySelectorAll('.show tr')[1].appendChild(td3);
    var td4 = document.createElement("td");
    td4.innerHTML=price;
    td4.classList.add("decorate");
    document.querySelectorAll('.show tr')[1].appendChild(td4);
    
    
</script>
           <?php
        }
    }
    else
    {?>
         <script>
         alert("please write the correct id number");
        
         </script>
         <?php
    }

}
?>