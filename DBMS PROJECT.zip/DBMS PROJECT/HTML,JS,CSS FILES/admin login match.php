<?php
session_start();
$servername = "localhost";
$username="root";
$password="";
$dbname="bike rental";
//stablish connection 
$conn= new mysqli($servername,$username,$password,$dbname);
//check connection
if($conn->connect_error)
{
  die("could not connect:");
}
$user_i= $_POST["uusername"]; 
$pass=$_POST["upassword"]; 
 
$sql = "SELECT * FROM admin  WHERE user_id='$user_i' and password='$pass'";
//this will send the result
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0)
{
  while($row=mysqli_fetch_assoc($result))
  {
       if($row["user_id"]==$user_i&&$row["password"]==$pass)
       {
        $_SESSION["user"] = $user_i;
        $_SESSION["success"] = "You are now logged in";
         ?>
         <script>
         alert("logged in seccesfully");
         </script>
         <?php
         //here u can include what ever u want
         
         header('location:  admin add vehicle.php');
       }  
       else{
         ?>
         
        <script>
        alert("incredential login");
        window.history.back();
        </script>
        <?php
       
       } 
  }
}
else
{
  ?>
  <script>
        alert("incredential login");
        window.history.back();
  </script>
  <?php
  
}
mysqli_close($conn);
?>