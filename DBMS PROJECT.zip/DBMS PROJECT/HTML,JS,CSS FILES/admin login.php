<!doctype>
<html>
<head>

 <link rel="stylesheet" href="loginstyle.css">
<link href="https://fonts.googleapis.com/css?family=Dancing+Script&display=swap" rel="stylesheet">
<style>
  .form_lab 
  {
    color: black;

  }
    </style>
</head>
<body>
<header>
  
<div id ="container">



<form action="admin login match.php" method="post" >
<label class="form_lab"  for="username">userid:</label>
<input type="text" id="username" name="uusername" required><br>
<label  class="form_lab" for="password">password:</label>
<input type="password" id="password" name="upassword" required><br>
<input type="submit" name="oop" value="login" onclick="next():">

</form>

</div>
</header>
</body>



</html>