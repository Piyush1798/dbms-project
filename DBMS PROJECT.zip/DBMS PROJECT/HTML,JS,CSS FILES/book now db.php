
<?php
session_start();
if(!isset($_SESSION["username"]))
{
    ?>
    <script>
       
        window.history.back();
        </script>
    <?php
    

}

?>
<html >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>book now</title>
<link rel="stylesheet" type="text/css" href="view.css" media="all">
<link rel="stylesheet" href="hh.css">
<link rel="stylesheet" href="styles.css">
<link href="https://fonts.googleapis.com/css?family=Arvo" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    
<div class="selector">  
<?php
include("new head.php");
?>
  <h1 id="title"></h1>
  <h1 >please select one vehicle</h1>
  <div class="set">
    
   
  </div>
  <button class="submit">submit</button>
 
 

  <footer>
    Made with ❤️ in india.
  </footer>
  <div>


       <div class="footer">
           <p>thank you....for visiting</p>
       </div>

</div>
</body>
</html>



<script>
 
 

<?php



$servername = "localhost";
$username="root";
$password="";
$dbname="bike rental";
//stablish connection 
$conn= new mysqli($servername,$username,$password,$dbname);
//check connection
if($conn->connect_error)
{
  die("could not connect:");
}

$veh_type= $_POST["element_6"]; 
$baname= $_POST["bname"];
$pdatemm=$_POST["datemm"]; 
$pdatedd=$_POST["datedd"];
$pdateyy=$_POST["dateyy"]; 
$ddatemm=$_POST["ddatemm"]; 
$ddatedd=$_POST["ddatedd"];
$ddateyy=$_POST["ddateyy"]; 
$ptimehh=$_POST["ptimehh"]; 
$ptimemm=$_POST["ptimemm"];
$ptimess=$_POST["ptimess"];
$pselect_p=$_POST["select_p"];
$dtimehh=$_POST["dtimehh"]; 
$dtimemm=$_POST["dtimemm"];
$dtimess=$_POST["dtimess"];
$pselect_d=$_POST["select_d"];

$sql="SELECT veh_id  from vehicle where brand_name='$baname' and veh_type='$veh_type' ";
$sql_count="SELECT count(*) as count  from vehicle where brand_name='$baname' and veh_type='$veh_type' ";//here we will find the number of vehicle in vehicle table which satisfy the app condition
$idd="";
$result=mysqli_query($conn,$sql);
$capacity=0;
if(mysqli_num_rows($result)>0)
{

   
  $sql2="SELECT  veh_id from book where veh_id in (SELECT veh_id from vehicle where brand_name='$baname' and veh_type='$veh_type') ";
  $sql_count1="SELECT count(*) as count from book where veh_id in (SELECT veh_id from vehicle where brand_name='$baname' and veh_type='$veh_type') ";
  $result2=mysqli_query($conn,$sql2);
  if(mysqli_num_rows($result2)>0)
   {

    
   
   }
   
    $result3=mysqli_query($conn,$sql_count);//here only for the college
    if(mysqli_num_rows($result3)>0)
     {
      while($row=mysqli_fetch_assoc($result3))
      {
        $capacity=$row['count']-mysqli_num_rows($result2);
        
      }
     }
     
     if($capacity)
     {
      $sql2="SELECT veh_id  from vehicle where brand_name='$baname' and veh_type='$veh_type' and veh_id  not in (SELECT  veh_id from book where veh_id in (SELECT veh_id from vehicle where brand_name='$baname' and veh_type='$veh_type')) ";
      $result6=mysqli_query($conn,$sql2);
    
    if(mysqli_num_rows($result6)>0)
     {
       while($row_1=mysqli_fetch_assoc($result6))
       {
         $idd=$row_1['veh_id'];
       }
     }
     else{
      ?>
    
      alert("locha");
      
      window.history.back();
      <?php
     }
     
     }
     else
     {
      ?>
    
      alert("sorry no matching will available");
      
      window.history.back();
      <?php
     }
    
  ?>
  

  <?php
}
else
{
    ?>
    
    alert("please write the correct brand name");
    window.history.back();
  
    <?php
}

?>

var cap='<?php echo $capacity;?>';
 //javascript
 //alert(cap);
 if(cap)
 {   var arr=[];
    for(var i=0;i<cap;i++){
var btn = document.createElement("BUTTON");
//btn.innerHTML=i+1;
btn.classList.add("drum");
document.querySelector('.set').appendChild(btn);

}
var count=0;
for(var i=0;i<cap;i++)
{
    document.querySelectorAll("BUTTON")[i].addEventListener("click",function()
    {
        
        
		var p= this.classList.toggle("pressed");
		
        
        if(p==true)
		{
			count=this.innerHTML;
		    arr.push(true);
		}
        else{
		count=0;
		arr.pop();
		}
    });
}

document.querySelector(".submit").addEventListener('click',function(){
 
	if(arr.length!=1)
	{
	  alert("please select only one bike");
	  location.reload();
    
    
  
 
	}
	else{

	<?php
  $rand=mt_rand(10,100);
  $indate=$pdatemm." ".$pdatedd." ".$pdateyy;
  $outdate=$ddatemm." ".$ddatedd." ".$ddateyy;
  $intime=$ptimehh." ".$ptimemm." ".$ptimess;
  $ontime=$dtimehh." ".$dtimemm." ".$dtimess;
  $uid=$_SESSION['username'];
  
  ?>
    
    alert('<?php echo $idd;?>');
    
  
    <?php
  $sqls="INSERT INTO book (booking_id,veh_id,user_id,in_date,out_date,in_time,out_time,decision)
  VALUES('$rand','$idd','$uid','$indate','$outdate','$intime','$ontime','pending')";
  if($conn->query($sqls)==true)
  {
    ?>
    
    alert("congratulation u have been successfull y register for booking please check my booking for furthur information");
    window.history.back();
  
    <?php
  }
  else{
    ?>
    
    alert('<?php echo $conn->connect_error;?>');
   
  
    <?php
  }
  ?>
}
 });
    
 }
 else{
     alert(" sorry all bikes are booked");
     window.history.back();
 }  
 


 
</script>