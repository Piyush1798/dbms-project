<?php
session_start();
if(!isset($_SESSION["username"]))
{
    ?>
    <script>
       
        window.history.back();
        </script>
    <?php
    

}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>book now</title>
<link rel="stylesheet" type="text/css" href="view.css" media="all">
<script type="text/javascript" src="view.js"></script>
<script type="text/javascript" src="calendar.js"></script>
<link rel="stylesheet" href="hh.css">
<link rel="stylesheet" href="styles.css">
<link href="https://fonts.googleapis.com/css?family=Arvo" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
    <body id="main_body">
        <div class="head_container">
          <h2>Bike rental</h2>
          <div class="navbar">
            <a class="active" href="homy.php"><i class="fa fa-fw fa-home"></i> Home</a>
            <a href="mybooking.php"><i class="fa fa-fw fa-users"></i> my booking</a>
            <a href="book now.php"><i class="fa fa-fw fa-motorcycle"></i> book now</a>
            <a href="contact us.php"><i class="fa fa-fw fa-envelope"></i> contact us</a>
            <a href="login.php"><i class="fa fa-fw fa-user"></i> Login/register</a>
			<a href="logout.php"><i class="fa fa-fw fa-user"></i> Logout</a>
          </div>
        </div>
        
         

        <img id="top" src="top.png" alt="">
	<div id="form_container">
	
		<h1><a>book now</a></h1>
		<form action="book now db.php" method=post id="form_112236" class="appnitro"  >
					<div class="form_description">
			<h2>book now</h2>
			<p></p>
		</div>						
			<ul >
			
					<li id="li_6" >
		<label class="description" for="element_6">select type </label>
		<span>
			<input id="element_6_1" name="element_6" class="element radio" type="radio" value="bike" />
<label class="choice" for="element_6_1">bike</label>
<input id="element_6_2" name="element_6" class="element radio" type="radio" value="scooty" />
<label class="choice" for="element_6_2">scooty</label>

		</span> 
		</li>		<li id="li_1" >
		<label class="description" for="element_1">select brand </label>
		<div>
			<input name="bname" id="element_1" name="element_1" class="element text medium" type="text" maxlength="255" value=""/> 
		</div> 
		</li>		<li id="li_2" >
		<label class="description" for="element_2">pickup date </label>
		<span>
			<input name="datemm" id="element_2_1" name="element_2_1" class="element text" size="2" maxlength="2" value="" type="text"> /
			<label for="element_2_1">MM</label>
		</span>
		<span>
			<input name="datedd" id="element_2_2" name="element_2_2" class="element text" size="2" maxlength="2" value="" type="text"> /
			<label for="element_2_2">DD</label>
		</span>
		<span>
	 		<input name="dateyy" id="element_2_3" name="element_2_3" class="element text" size="4" maxlength="4" value="" type="text">
			<label for="element_2_3">YYYY</label>
		</span>
	
		<span id="calendar_2">
			<img id="cal_img_2" class="datepicker" src="calendar.gif" alt="Pick a date.">	
		</span>
		<script type="text/javascript">
			Calendar.setup({
			inputField	 : "element_2_3",
			baseField    : "element_2",
			displayArea  : "calendar_2",
			button		 : "cal_img_2",
			ifFormat	 : "%B %e, %Y",
			onSelect	 : selectDate
			});
		</script>
		 
		</li>		<li id="li_3" >
		<label class="description" for="element_3">dropping date </label>
		<span>
			<input name="ddatedd" id="element_3_1" name="element_3_1" class="element text" size="2" maxlength="2" value="" type="text"> /
			<label for="element_3_1">MM</label>
		</span>
		<span>
			<input name="ddatemm" id="element_3_2" name="element_3_2" class="element text" size="2" maxlength="2" value="" type="text"> /
			<label for="element_3_2">DD</label>
		</span>
		<span>
	 		<input name="ddateyy" id="element_3_3" name="element_3_3" class="element text" size="4" maxlength="4" value="" type="text">
			<label for="element_3_3">YYYY</label>
		</span>
	
		<span id="calendar_3">
			<img id="cal_img_3" class="datepicker" src="calendar.gif" alt="Pick a date.">	
		</span>
		<script type="text/javascript">
			Calendar.setup({
			inputField	 : "element_3_3",
			baseField    : "element_3",
			displayArea  : "calendar_3",
			button		 : "cal_img_3",
			ifFormat	 : "%B %e, %Y",
			onSelect	 : selectDate
			});
		</script>
		 
		</li>		<li id="li_4" >
		<label class="description" for="element_4">pickup time </label>
		<span>
			<input name="ptimehh" required id="element_4_1" name="element_4_1" class="element text " size="2" type="text" maxlength="2" value=""/> : 
			<label>HH</label>
		</span>
		<span>
			<input  name="ptimemm" required id="element_4_2" name="element_4_2" class="element text " size="2" type="text" maxlength="2" value=""/> : 
			<label>MM</label>
		</span>
		<span>
			<input  name="ptimess" required id="element_4_3" name="element_4_3" class="element text " size="2" type="text" maxlength="2" value=""/>
			<label>SS</label>
		</span>
		<span>
			<select  name="select_p" class="element select" style="width:4em" id="element_4_4" name="element_4_4">
				<option required value="AM" >AM</option>
				<option required value="PM" >PM</option>
			</select>
			<label>AM/PM</label>
		</span> 
		</li>		<li id="li_5" >
		<label  class="description" for="element_5">dropup time </label>
		<span>
			<input name="dtimehh"  required id="element_5_1" name="element_5_1" class="element text " size="2" type="text" maxlength="2" value=""/> : 
			<label>HH</label>
		</span>
		<span>
			<input name="dtimemm"  required  id="element_5_2" name="element_5_2" class="element text " size="2" type="text" maxlength="2" value=""/> : 
			<label>MM</label>
		</span>
		<span>
			<input name="dtimess"  required  id="element_5_3" name="element_5_3" class="element text " size="2" type="text" maxlength="2" value=""/>
			<label>SS</label>
		</span>
		<span>
			<select name="select_d"  class="element select" style="width:4em" id="element_5_4" name="element_5_4">
				<option required  value="AM" >AM</option>
				<option required  value="PM" >PM</option>
			</select>
			<label>AM/PM</label>
		</span> 
		</li>
			
					<li class="buttons">
			    <input required  type="hidden" name="form_id" value="112236" />
			    
			  <input required  id="saveForm" class="button_text" type="submit" name="submit" value="Submit" />
				
		</li>
			</ul>
		</form>	
	
		<div id="footer">
			Generated by <a href="http://www.phpform.org">pForm</a>
		</div>
	</div>
	<img id="bottom" src="bottom.png" alt="">
   
  

  
  

       <div class="footer">
           <p>thank you....for visiting</p>
       </div>
</body> 
</html>

