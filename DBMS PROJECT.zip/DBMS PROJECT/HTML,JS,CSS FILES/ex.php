<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title>Drum Kit</title>
  <link rel="stylesheet" href="styles.css">
  <link href="https://fonts.googleapis.com/css?family=Arvo" rel="stylesheet">
</head>

<body>

  <div class="selector">  
  <h1 id="title">Drum 🥁 Kit</h1>
  <div class="set">
    <button class="w drum"></button>
   
  </div>
  <button class="submit">submit</button>
  <script type="text/javascript" src="ne.js"></script>
  <footer>
    Made with ❤️ in india.
  </footer>
  <div>
</body>

</html>
