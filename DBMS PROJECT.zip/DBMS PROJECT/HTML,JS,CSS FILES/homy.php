
<html>
    <head>
    <link rel="stylesheet" href="hh.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <div class="head_container">
          <h1>Bike rental</h1>
          <div class="navbar">
            <a class="active" href="homy.php"><i class="fa fa-fw fa-home"></i> Home</a>
            <a href="mybooking.php"><i class="fa fa-fw fa-users"></i> my booking</a>
            <a href="book now.php"><i class="fa fa-fw fa-motorcycle"></i> book now</a>
            <a href="#"><i class="fa fa-fw fa-envelope"></i> contact us</a>
            <a href="login.php"><i class="fa fa-fw fa-user"></i> Login/register</a>
            
          </div>
        </div>
        <div class="middle">
        <div class="image">
            <img src="woman-in-gray-shirt-riding-black-motor-scooter-809609.jpg">
        </div>
   
    
        <div class="scooter">
        <img src="https://www.animatedimages.org/data/media/73/animated-motorbike-image-0037.gif" border="0" alt="animated-motorbike-image-0037" style="position: 'absolute';"/> 
        <p class="displya-1"> scooter </p>
        </div>
        <div class="bike">
        <img  src="https://www.animatedimages.org/data/media/73/animated-motorbike-image-0051.gif" border="0" alt="animated-motorbike-image-0051"style="position: 'absolute';" />
        <p class="displya-1"> bike </p>
        </div>
       </div>
       <div class="footer">
           <p>thank you....for visiting</p>
       </div>
</body> 
</html>

