<?php
$servername = "localhost";
$username="root";
$password="";
$dbname="bike rental";
//stablish connection 
$conn= new mysqli($servername,$username,$password,$dbname);
//check connection
if($conn->connect_error)
{
  die("could not connect:");
}
$user_i= $_POST["user_id"]; 
$pass= $_POST["upass"];
$name=$_POST["name"]; 
$mob_no=$_POST["mobile_no"]; 
echo $_POST["upass"];
$sql="INSERT INTO user (user_id,password, user_name,phone)
VALUES ('$user_i','$pass','$name','$mob_no')";
if($conn->query($sql)==true)
{
  echo "data inserted";
}
else
{
  echo "could not poss"  . $sql . "<br>" . $conn->error;
}
?>