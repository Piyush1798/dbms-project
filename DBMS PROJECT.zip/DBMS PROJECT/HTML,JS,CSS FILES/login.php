<!doctype>
<html>
<head>

 <link rel="stylesheet" href="loginstyle.css">
<link href="https://fonts.googleapis.com/css?family=Dancing+Script&display=swap" rel="stylesheet">
<style>
label
{
    color: black;
}
</style>
</head>
<body>
<header>
    <?php include 'new head.php'?>
<div id ="container">



<form action="loginmatch.php" method="post" >
<label for="username">userid:</label>
<input type="text" id="username" name="uusername" required><br>
<label for="password">password:</label>
<input type="password" id="password" name="upassword" required><br>
<input type="submit" name="oop" value="login" onclick="next():">

</form>

</div>
</header>
</body>



</html>
