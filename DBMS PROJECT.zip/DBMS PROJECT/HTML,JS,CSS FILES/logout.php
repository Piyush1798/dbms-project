<?php
session_start();
if(!isset($_SESSION["username"]))
{
    ?>
    <script>
       
        window.history.back();
        </script>
    <?php
    

}
else
{
    unset($_SESSION['username']);
    ?>
    <script>
       
        window.history.back();
        </script>
    <?php
}
?>