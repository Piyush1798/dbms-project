<?php
session_start();
if(!isset($_SESSION["username"]))
{
    ?>
    <script>
       
        window.history.back();
        </script>
    <?php
    

}
include("new head.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>

  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
  <style>
    /* Set height of the grid so .sidenav can be 100% (adjust if needed) */
    .row.content {height: 1500px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      background-color: #f1f1f1;
      height: 100%;
    }
    
    /* Set black background color, white text and some padding */
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
    
    /* On small screens, set height to 'auto' for sidenav and grid */
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height: auto;} 
    }
   .ddd 
   {
    height: 600px;
    width : 400px;
    margin-left: 50%;
    margin-right: 50%;

   }
  h1
  {
    font-family: "Arial Black", Gadget, sans-serif;
font-size: 29px;
letter-spacing: -0.2px;
word-spacing: 1px;
color: #000000;
font-weight: 700;
text-decoration: none;
font-style: normal;
font-variant: normal;
text-transform: uppercase;
text-align: center;

  }
  .show 
  {
    text-align: center;
    margin-left:20%;
  }
  .decorate
{
    

letter-spacing: 2px;
word-spacing: 2px;
color: #000000;
font-weight: 700;
text-decoration: none;
font-style: normal;
font-variant: normal;
text-transform: none;

margin-top:10px;

padding:10px;
padding-left:10px;
padding-right:10px;
}
table {
  border-collapse: collapse;
  text-align:center;
}

th, td {
  text-align: left;
  padding: 8px;
}

th {background-color: #f2f2f2;}
  </style>
</head>
<body>

<div class="container-fluid">
  
    

<table  class="show" style="overflow-x:auto; " >
<tr>
   
</tr>
<tr>
    
</tr>
</table>

</div>



</body>
</html>



<?php

if(!isset($_SESSION["username"]))
{
    ?>
    <script>
       
        window.history.back();
        </script>
    <?php
    

}
else
{
    $servername="localhost";
    $password="";
    $username="root";
    $dbname="bike rental";
    //con making;
    $conn=new mysqli($servername,$username,$password,$dbname);
    if($conn->connect_error)
    {
        die("cannot connect");
    }
    
    $uy=$_SESSION["username"];
    $sql="SELECT * FROM book  WHERE user_id ='$uy'";
    $result=$conn->query($sql);
    
    if($result->num_rows>0)
    {
        while($row=$result->fetch_assoc())
        {
           $vv=$row['veh_id'];
            ?>
           <script type="text/javascript">
    var id = "<?php echo $vv; ?>";
    var bid="<?php echo $row['booking_id']; ?>";
    var in_date="<?php echo $row['in_date']; ?>";
    var out_date="<?php echo $row['out_date']; ?>";
    var in_time="<?php echo $row['in_time']; ?>";
    var out_time="<?php echo $row['out_time']; ?>";
    var decision="<?php echo $row['decision']; ?>";
    
    var btn = document.createElement("th");
    btn.innerHTML="booking id";
    btn.classList.add("decorate");
    document.querySelector('.show tr').appendChild(btn);
    var btn1 = document.createElement("th");
    btn1.innerHTML="user id";
    btn1.classList.add("decorate");
    document.querySelector('.show tr').appendChild(btn1);
    var btn2 = document.createElement("th");
    btn2.innerHTML="vehicle id";
    btn2.classList.add("decorate");
    document.querySelector('.show tr').appendChild(btn2);
    var btn3 = document.createElement("th");
    btn3.innerHTML="in date";
    btn3.classList.add("decorate");
    document.querySelector('.show tr').appendChild(btn3);
    var btn4 = document.createElement("th");
    btn4.innerHTML="out date";
    btn4.classList.add("decorate");
    document.querySelector('.show tr').appendChild(btn4);
    var btn5 = document.createElement("th");
    btn5.innerHTML="in time";
    btn5.classList.add("decorate");
    document.querySelector('.show tr').appendChild(btn5);
    var btn6 = document.createElement("th");
    btn6.innerHTML="out time";
    btn6.classList.add("decorate");
    document.querySelector('.show tr').appendChild(btn6);
    var btn7 = document.createElement("th");
    btn7.innerHTML="decision";
    btn7.classList.add("decorate");
    document.querySelector('.show tr').appendChild(btn7);
    var td1 = document.createElement("td");
    td1.innerHTML=bid;
    td1.classList.add("decorate");
    document.querySelectorAll('.show tr')[1].appendChild(td1);
    
    var td2 = document.createElement("td");
    td2.innerHTML='<?php echo $_SESSION['username'];?>';
    td2.classList.add("decorate");
    document.querySelectorAll('.show tr')[1].appendChild(td2);
    var td3 = document.createElement("td");
    td3.innerHTML=id;
    td3.classList.add("decorate");
    document.querySelectorAll('.show tr')[1].appendChild(td3);
    var td4 = document.createElement("td");
    td4.innerHTML=in_date;
    td4.classList.add("decorate");
    document.querySelectorAll('.show tr')[1].appendChild(td4);
    var td5 = document.createElement("td");
    td5.innerHTML=out_date;
    td5.classList.add("decorate");
    document.querySelectorAll('.show tr')[1].appendChild(td5);
    var td6 = document.createElement("td");
    td6.innerHTML=in_time;
    td6.classList.add("decorate");
    document.querySelectorAll('.show tr')[1].appendChild(td6);
    var td7 = document.createElement("td");
    td7.innerHTML=out_time;
    td7.classList.add("decorate");
    document.querySelectorAll('.show tr')[1].appendChild(td7);
    var td8 = document.createElement("td");
    td8.innerHTML=decision;
    td8.classList.add("decorate");
    document.querySelectorAll('.show tr')[1].appendChild(td8);
    
    
    
    
</script>
           <?php
        }
    }
    else
    {?>
         <script>
         alert("you have no booking yet");
         window.history.back();
         </script>
         <?php
    }

}
?>