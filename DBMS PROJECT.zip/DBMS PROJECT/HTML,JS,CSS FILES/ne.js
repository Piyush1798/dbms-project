
   
   
    var a=8;
    alert(a);
    for(var i=0;i<5;i++){
var btn = document.createElement("BUTTON");
btn.classList.add("drum");
document.querySelector('.set').appendChild(btn);
}
var count=0;
for(var i=0;i<5;i++)
{
    document.querySelectorAll("BUTTON")[i].addEventListener("click",function()
    {
        
        
        var p= this.classList.toggle("pressed");
        alert(console.count());
        if(p==true)
        count++;
        else
        {
        count--;
        this.classList
        }
    });
}

document.querySelector(".submit").addEventListener('click',function(){
    if(count<0)
{
    count=0;
}
    document.querySelector(".submit").innerHTML=count;
});
   
    

