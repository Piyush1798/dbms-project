<?php
$run = 5;
if($run>1){
   
    ?>
    <script type='text/javascript'>
   
    var a=<?php echo $run; ?>;
    alert(a);
    for(var i=0;i<a;i++){
var btn = document.createElement("BUTTON");
btn.classList.add("drum");
document.querySelector('.set').appendChild(btn);
}
var count=0;
for(var i=0;i<5;i++)
{
    document.querySelectorAll("BUTTON")[i].addEventListener("click",function()
    {
        
        
        var p= this.classList.toggle("pressed");
        //alert(p);
        if(p==true)
        count++;
        else
        count--;
    });
}

document.querySelector(".submit").addEventListener('click',function(){
    if(count<0)
{
    count=0;
}
    document.querySelector(".submit").innerHTML=count;
});
    </script>
    
    <?php
}
else
echo "The condition has been satisfied";
?>
