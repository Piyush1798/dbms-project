<!doctype>
<html>
    <head>
    <link rel="stylesheet" href="hh.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <div class="head_container">
          <h2>Bike rental</h2>
          <div class="navbar">
            <a href="homy.php"><i class="fa fa-fw fa-home"></i> Home</a>
            <a href="mybooking.php"><i class="fa fa-fw fa-users"></i> my booking</a>
            <a href="book now.php"><i class="fa fa-fw fa-motorcycle"></i> book now</a>
            <a href="contact us.php"><i class="fa fa-fw fa-envelope"></i> contact us</a>
            <a href="login.php"><i class="fa fa-fw fa-user"></i> Login/register</a>
            <a href="logout.php"><i class="fa fa-fw fa-user"></i> Logout</a>
            
            <a href="signup.php"><i class="fa fa-fw fa-user"></i> signup</a>
          </div>
          </div>
    </body> 
</html>